#!/bin/bash

rm -Rf $HOME/IT/severo.*/*
rm -Rf $HOME/TRACES/*
rm -Rf $HOME/COMPSs-SCO/Stubs
