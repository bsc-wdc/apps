
package severo.consumer;

import integratedtoolkit.types.annotations.Method;


public interface ConsumerDataClayItf {

	@Method(declaringClass = "severo.molecule.Molecule")
	void printCenterOfMass();
	
}
