package severo.consumer;

import integratedtoolkit.types.annotations.Method;
import integratedtoolkit.types.annotations.Parameter;
import integratedtoolkit.types.annotations.Parameter.Direction;
import integratedtoolkit.types.annotations.Parameter.Type;
import severo.molecule.Molecule;

public interface ConsumerRacerItf {

	@Method(declaringClass = "severo.consumer.ConsumerRacer")
	void doMoleculeOffsetX(
			@Parameter(type = Type.OBJECT, direction = Direction.INOUT)
			Molecule molecule,
			@Parameter(type = Type.INT, direction = Direction.IN)
			int m);

	@Method(declaringClass = "severo.consumer.ConsumerRacer")
	void doMoleculeOffsetY(
			@Parameter(type = Type.OBJECT, direction = Direction.INOUT)
			Molecule molecule,
			@Parameter(type = Type.INT, direction = Direction.IN)
			int m);

	@Method(declaringClass = "severo.consumer.ConsumerRacer")
	void doMoleculeOffsetZ(
			@Parameter(type = Type.OBJECT, direction = Direction.INOUT)
			Molecule molecule,
			@Parameter(type = Type.INT, direction = Direction.IN)
			int m);

	@Method(declaringClass = "severo.molecule.Molecule")
	void computeCenterOfMass();;

}
