package severo.producer;

import integratedtoolkit.types.annotations.Method;
import integratedtoolkit.types.annotations.Parameter;
import integratedtoolkit.types.annotations.Parameter.Type;

import severo.moleculeArray.Molecule;

public interface ProducerDataClayItf {

    @Method(declaringClass = "severo.moleculeArray.Molecule")
    void computeCenterOfMass();

    @Method(declaringClass = "severo.moleculeArray.Molecule")
    void init(
            @Parameter int n
    );
    
    @Method(declaringClass = "severo.moleculeArray.Molecule")
    void makePersistent(
            @Parameter(type = Type.STRING) String alias
    );
    
} 
