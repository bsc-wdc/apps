
package severo.consumer;

import integratedtoolkit.types.annotations.Method;


public interface ConsumerItf {

	@Method(declaringClass = "severo.molecule.Molecule")
	void printCenterOfMass();
	
}
